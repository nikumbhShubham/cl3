import numpy as np
from sklearn.neural_network import MLPRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import random
import warnings

# Suppress convergence warnings for cleaner output during the optimization
warnings.filterwarnings("ignore")

# 1. SIMULATED DATA: Spray Drying of Coconut Milk
# Features represent physical parameters: [Inlet Temp (C), Feed Rate (ml/min), Atomizer Speed (rpm), Concentration (%), Air Flow]
print(" Initializing Coconut Milk Spray Drying Model")
X = np.random.rand(100, 5) 
# Target: Quality metric of the dried powder (e.g., moisture content or yield)
y = np.sum(X, axis=1) + np.random.rand(100) * 0.1

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 2. FITNESS FUNCTION (The Hybrid NN Evaluation)
def fitness(params):
    """
    Evaluates how well a specific set of GA parameters performs 
    when used to model the spray drying process via a Neural Network.
    """
    pop_size, crossover_rate, mutation_rate = params
    # Train a Neural Network to predict the drying outcome
    model = MLPRegressor(hidden_layer_sizes=(50,), max_iter=200, random_state=42)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    # The fitness is the inverse of error (lower MSE = better fitness)
    return mean_squared_error(y_test, y_pred)

# 3. GENETIC ALGORITHM OPERATORS
def create_individual():
    """Generates a random candidate for GA parameters."""
    return [
        random.randint(10, 100),    # Population Size
        random.uniform(0.5, 0.9),   # Crossover Rate
        random.uniform(0.01, 0.2)   # Mutation Rate
    ]

def mutate(ind):
    """Introduces random variation to the parameters."""
    if random.random() < 0.2: ind[0] = random.randint(10, 100)
    if random.random() < 0.2: ind[1] = random.uniform(0.5, 0.9)
    if random.random() < 0.2: ind[2] = random.uniform(0.01, 0.2)
    return ind

def crossover(p1, p2):
    """Combines two parent configurations to create a child."""
    return [
        random.choice([p1[0], p2[0]]),
        random.choice([p1[1], p2[1]]),
        random.choice([p1[2], p2[2]])
    ]

# 4. USER INPUT SECTION
try:
    print("\n--- GA Parameter Configuration ---")
    user_gens = int(input("Enter number of Generations to run (e.g., 5-10): "))
    user_pop_size = int(input("Enter Initial GA Population Size (e.g., 10-20): "))
except ValueError:
    print("Invalid input. Using default values (Gens: 5, Pop: 10)")
    user_gens, user_pop_size = 5, 10

# 5. MAIN GA OPTIMIZATION LOOP
population = [create_individual() for _ in range(user_pop_size)]

print("\nStarting Hybrid GA-NN Optimization...")
for gen in range(user_gens):
    # Calculate fitness for every individual in the population
    scores = [(fitness(ind), ind) for ind in population]
    # Sort by MSE (lowest error first)
    scores.sort(key=lambda x: x[0])
    
    print(f"Generation {gen} - Best Quality Prediction MSE: {scores[0][0]:.6f}")

    # Selection: Take the top 50% performers
    selected = [ind for (_, ind) in scores[:max(2, user_pop_size // 2)]]
    
    # Reproduction: Create next generation
    new_population = selected.copy()
    while len(new_population) < user_pop_size:
        p1, p2 = random.sample(selected, 2)
        child = crossover(p1, p2)
        child = mutate(child)
        new_population.append(child)
    population = new_population

# 6. RESULTS
best_params = min(population, key=lambda x: fitness(x))
# print("\n" + "="*50)
print("OPTIMIZED HYBRID PARAMETERS FOR COCONUT MILK DRYING")
# print("="*50)
print(f"Optimal GA Population Size: {best_params[0]}")
print(f"Optimal Crossover Rate:     {best_params[1]:.4f}")
print(f"Optimal Mutation Rate:      {best_params[2]:.4f}")
# print("="*50)